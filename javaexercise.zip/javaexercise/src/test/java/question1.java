import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.springframework.util.Assert;

public class question1 {

    WebDriver driver = new ChromeDriver();
            System.setProperty("webdriver.chrome.driver","/path/to/chromedriver");
                driver.get("http://www.google.com/");
    WebElement login = driver.findElement(By.cssSelector(".login"));
    WebElement email = driver.findElement(By.id("#email"));
                email.sendKeys("jetblue@grr.la");
    WebElement password = driver.findElement(By.id("#passwd"));
                password.sendkeys("jetblue");
    WebElement submit = driver.findElement(By.cssSelector(".icon-lock left"));

            submit.click();
    //next page
    categorytshirt =driver.findElement(By.ByXPath("//a[contains(text(),'T-shirts')]"));
    categorytshirt.click();
    categorytshirt =driver.findElement(By.ByXPath("//a[contains(text(),'Faded Short Sleeve T-shirts')]"));
    categorytshirt.click();
    addtocart =   driver.findElement(By.ByXPath("//span[.='Add to cart']"));
    addtocart.click();
    proceedtocheckout =   driver.findElement(By.ByCssSelector(".btn btn-default button button-medium"));
    proceedtocheckout.click();
    Assert.assertThat(driver.findeElement(By.ById("#summary_products_quantity")).toString().equals("2 Products"))


}
