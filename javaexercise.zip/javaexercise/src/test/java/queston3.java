public class queston3 {


    RequestSpecification request = RestAssured.given();
    // Setting Base URI
		request.baseUri("http://api.openweathermap.org");
    // Setting Base Path
		request.basePath("/data/3.0/stations");

    Response response = request.get();

		System.out.println(response.asString());
}
